@echo off
setlocal enabledelayedexpansion

set "SERVICE_CONFIG_DIR=%LOCALAPPDATA%\Jujo.Stream\Server"
set "SERVICE_CONFIG_FILE=%SERVICE_CONFIG_DIR%\service_start_type.txt"

rem Save the current service start type to a file if the service exists
sc qc Jujo.Server >nul 2>&1
if %ERRORLEVEL%==0 (
    if not exist "%SERVICE_CONFIG_DIR%\" mkdir "%SERVICE_CONFIG_DIR%\"

    rem Get the start type
    for /f "tokens=3" %%i in ('sc qc Jujo.Server ^| findstr /C:"START_TYPE"') do (
        set "CURRENT_START_TYPE=%%i"
    )

    rem Set the content to write
    if "!CURRENT_START_TYPE!"=="2" (
        sc qc Jujo.Server | findstr /C:"(DELAYED)" >nul
        if !ERRORLEVEL!==0 (
            set "CONTENT=2-delayed"
        ) else (
            set "CONTENT=2"
        )
    ) else if "!CURRENT_START_TYPE!" NEQ "" (
        set "CONTENT=!CURRENT_START_TYPE!"
    ) else (
        set "CONTENT=unknown"
    )

    rem Write content to file
    echo !CONTENT!> "%SERVICE_CONFIG_FILE%"
)

rem Stop and delete the legacy SunshineSvc service (best-effort)
call :stop_and_delete_service sunshinesvc 15

rem Stop and delete Jujo.Server and legacy services
call :stop_and_delete_service Jujo.Server 60

goto :eof

:stop_and_delete_service
set "TARGET_SERVICE=%~1"
set "WAIT_SECONDS=%~2"
set "SERVICE_PID="

if "%TARGET_SERVICE%"=="" goto :eof
if not defined WAIT_SECONDS set "WAIT_SECONDS=30"

sc query "%TARGET_SERVICE%" >nul 2>&1
if errorlevel 1 goto :delete_service

sc stop "%TARGET_SERVICE%" >nul 2>&1

for /L %%i in (1,1,%WAIT_SECONDS%) do (
    sc query "%TARGET_SERVICE%" | findstr /C:"STATE" | findstr /C:"STOPPED" >nul 2>&1 && goto :delete_service
    timeout /t 1 >nul
)

for /f "tokens=3" %%p in ('sc queryex "%TARGET_SERVICE%" ^| findstr /C:"PID"') do (
    set "SERVICE_PID=%%p"
)

if defined SERVICE_PID (
    if /I not "!SERVICE_PID!"=="0" (
        taskkill /pid !SERVICE_PID! /f >nul 2>&1
        timeout /t 1 >nul
    )
)

:delete_service
sc delete "%TARGET_SERVICE%" >nul 2>&1
set "TARGET_SERVICE="
set "WAIT_SECONDS="
set "SERVICE_PID="
goto :eof
